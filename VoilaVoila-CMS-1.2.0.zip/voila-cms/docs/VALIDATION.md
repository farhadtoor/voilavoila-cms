# Validation 1.2.0 — 2026-10-25

## Résultats exécutés / Executed results

| Suite | Contrôles / Checks | Environnement / Runtime |
| --- | --- | --- |
| HTTP, SQLite, migration 1.0, documents/commentaires/WordPress 1.2 | 167 (50 + 35 + 2 + 80) | PHP 8.3.6, Python stdlib |
| Mise à jour réelle 1.1 → 1.2 / Actual archive upgrade | 8 | Archive 1.1.0 originale, PHP 8.3.6 |
| Navigateur FR/EN, ordinateur/mobile / Browser desktop/mobile | 18 | Chromium 156.0.8078.47, Playwright 1.62.1 |
| WordPress Porter inchangé / Unchanged Porter unit suite | 44 | PHP 8.3.6 |
| Total | 237 | Données synthétiques / Synthetic data |

Rapports / Reports: [HTTP](validation-1.2-http.json), [upgrade](validation-1.2-upgrade.json), [browser](validation-1.2-browser.json), [Porter](validation-1.2-porter.json).

Les scénarios 1.2 vérifient les quatre formats de documents, noms/MIME incohérents, ZIP corrompus, chemins et entrées spéciaux, taux d’expansion, DOCX avec objets actifs/relations externes/DDE/entités UTF-16, CSV binaire, accès privé, sauvegarde/restauration, jetons visiteurs invalides/expirés, modération, limites et purge. La détection des archives chiffrées est implémentée ; cette nouvelle suite ne fabrique pas directement un ZIP chiffré.

L’import est testé avec médias locaux, résumés/tags/dates, couvertures/galeries/liens, contenu privé/protégé/futur, commentaires en attente, répétition avec changement de titre et modification locale, annulation SQL et retrait des nouveaux fichiers après refus du plugin. Les identités WordPress et commentaires survivent à une restauration portable.

The suites cover documents, invalid archives/MIME, private delivery, restore, guest tokens/moderation/limits, local WXR/media/link mapping, private/protected/future content, repeat import, transaction/file rollback and preserved provenance. Encryption metadata is rejected by implementation; the new suite does not directly construct encrypted ZIPs.

## Limites / Limits

Les essais ont été exécutés localement sur PHP 8.3.6, pas sur toutes les versions du workflow. La CI GitHub 8.3/8.4/8.5 doit tourner dans votre dépôt. Hébergements mutualisés OVHcloud/Infomaniak, HTTPS Apache/Nginx réels, déploiement Docker et lanceur macOS n’ont pas été exécutés ici. Les captures de test utilisent uniquement des données synthétiques et ne sont pas embarquées dans le pack.

Local execution used PHP 8.3.6. Supplied GitHub 8.3/8.4/8.5 CI, real shared hosting/HTTPS, deployment Docker and macOS launcher remain unexecuted here. Synthetic screenshots are not bundled.

Pas d’audit externe, certification ou garantie d’absence de défaut. Les fichiers historiques `verification-*.json` concernent les versions précédentes. / No external audit, certification or defect-free guarantee. Historical `verification-*.json` covers earlier versions.

[Instructions FR](fr/tests.md) · [English instructions](en/testing.md)
