# Test CMS 1.2

## Current checks

```sh
python3 tools/check_repo.py
python3 tests/run.py --report test-results/current.json
node --check assets/admin.js
node --check assets/site.js
```

Personalize GitHub fields before the first check. Explicitly use `--allow-template` to review an unconfigured distribution. `tests/run.py --php /path/to/php` selects PHP.

Tests require PHP 8.3+, DOM, mbstring, fileinfo, PDO SQLite, GD JPEG/WebP and ZIP. Tokenizer is required for Porter scenarios. Python uses stdlib only. Tests create temporary source copies and synthetic state, run PHP on 127.0.0.1, then clean up. They do not target your live site.

Suites cover historical HTTP, SQLite/migration/logging, failed-migration retry and 1.2 documents/invalid archives/comments/expired tokens/restore/offline WordPress/repeat import/rollback. Actual executed counts are in [current validation](../VALIDATION.md).

## Actual 1.1 archive upgrade

Download original 1.1.0, then:

```sh
python3 tests/upgrade_120.py \
  --previous-zip /path/to/VoilaVoila-CMS-1.1.0.zip \
  --report test-results/upgrade.json
```

Its expected SHA is verified. The test installs 1.1, creates synthetic state, replaces source with 1.2 and checks access/content/settings/plugins/SQL integrity. The older archive is not bundled.

## Optional browser suite

Playwright is development-only; the CMS needs no npm/browser dependency.

```sh
npm install --prefix tests
cd tests
npx playwright install chromium
cd ..
python3 tests/browser_120.py --report test-results/browser.json
```

`tests/package.json` pins the module. Options: `--browser-path` for existing Chromium, `--php` and `--node`. `--qa-dir` stores synthetic local screenshots. Do not publish real-admin screenshots.

Scenarios cover DOCX upload, FR/EN insertion, download filename, comment/moderation, no-JS form, closing comments and 390 px layout. This is not a complete accessibility audit or Safari test.

## Docker and CI

```sh
docker build --build-arg PHP_VERSION=8.3 -f tests/Dockerfile -t vv-cms-tests .
docker run --rm vv-cms-tests
```

GitHub CI supplies PHP 8.3/8.4/8.5, read-only permissions and pinned checkout. Run it in your repository; supplied configuration is not proof of a passing run. Deployment Docker now configures JPEG/WebP, but an actual Docker/HTTPS hosting deployment remains to be checked.

Old `verification-*.json` reports cover 1.0/1.1 preparation. `validation-1.2-*.json` reports cover this milestone. No independent audit or defect-free guarantee is claimed.

[Playwright documentation](https://playwright.dev/docs/library).
