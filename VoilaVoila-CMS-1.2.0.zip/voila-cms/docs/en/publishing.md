# GitHub 1.2.0 — FR/EN

[Procédure complète / Full procedure](../../GITHUB-v1.2.0-FR-EN.md).

Dépôt existant ou nouveau, personnalisation, PR, tag v1.2.0, assets et Release. Gardez les tags publiés 1.0/1.1.

Existing/new repository, configuration, PR, v1.2.0 tag, assets and release. Keep published 1.0/1.1 tags.
