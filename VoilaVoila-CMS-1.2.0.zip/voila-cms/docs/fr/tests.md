# Vérifier le CMS 1.2

## Contrôles courants

```sh
python3 tools/check_repo.py
python3 tests/run.py --report test-results/current.json
node --check assets/admin.js
node --check assets/site.js
```

Personnalisez les informations GitHub avant le premier contrôle. Pour relire le modèle distribué, `python3 tools/check_repo.py --allow-template` est explicite. `--php /chemin/vers/php` permet de choisir le binaire de tests.

Le lanceur exige PHP 8.3+, DOM, mbstring, fileinfo, PDO SQLite, GD JPEG/WebP et ZIP. Tokenizer est requis pour les scénarios Porter. Python utilise uniquement sa bibliothèque standard. Les tests copient le code dans un dossier temporaire, y créent des données synthétiques, démarrent PHP sur 127.0.0.1 et nettoient à la fin. Ils ne ciblent pas votre site.

Suites : HTTP historique, SQLite/migration/journaux, migration échouée/reprise et scénarios 1.2 (documents, archives invalides, commentaires, jetons expirés, restauration, WordPress hors ligne, répétition et annulation). Les nombres réellement exécutés sont dans [validation courante](../VALIDATION.md).

## Passage réel depuis l’archive 1.1

Téléchargez l’archive originale 1.1.0, puis :

```sh
python3 tests/upgrade_120.py \
  --previous-zip /chemin/VoilaVoila-CMS-1.1.0.zip \
  --report test-results/upgrade.json
```

Son empreinte attendue est contrôlée. Le test installe réellement la 1.1, produit un état synthétique, remplace le code par la 1.2 et vérifie les accès, contenus, réglages, plugins et intégrité SQL. L’archive précédente n’est pas incluse dans le nouveau pack.

## Navigateur facultatif

Playwright est une dépendance de développement distincte ; aucun navigateur ou module npm n’est nécessaire au CMS.

```sh
npm install --prefix tests
cd tests
npx playwright install chromium
cd ..
python3 tests/browser_120.py --report test-results/browser.json
```

Le module est épinglé dans `tests/package.json`. Le script peut recevoir `--browser-path` pour un Chromium déjà installé, `--php` et `--node`. `--qa-dir` enregistre des captures de données synthétiques localement. Ne publiez pas des captures d’une vraie administration.

Sont contrôlés : upload DOCX, insertion FR/EN, nom de téléchargement, commentaire/modération, formulaire sans JS, fermeture et mise en page à 390 px. Ce n’est ni un audit d’accessibilité complet, ni un test Safari.

## Docker et CI

```sh
docker build --build-arg PHP_VERSION=8.3 -f tests/Dockerfile -t vv-cms-tests .
docker run --rm vv-cms-tests
```

Le workflow GitHub propose PHP 8.3/8.4/8.5 avec lecture seule et checkout épinglé. Cette matrice doit être exécutée dans votre dépôt : une configuration livrée ne prouve pas qu’elle est verte. Le Dockerfile de déploiement a été ajusté pour JPEG/WebP, mais son lancement réel et le déploiement HTTPS mutualisé restent à valider.

Les anciens `verification-*.json` concernent les préparations 1.0/1.1. Les rapports `validation-1.2-*.json` concernent ce jalon. Aucun audit indépendant ou garantie d’absence de défaut n’est annoncé.

[Documentation Playwright](https://playwright.dev/docs/library).
