<?php
declare(strict_types=1);
defined('VV_ROOT') || exit;
vv_shortcode('bonjour', function () {
    return '<p>' . e(t('Bonjour depuis mon extension !', 'Hello from my plugin!')) . '</p>';
});
