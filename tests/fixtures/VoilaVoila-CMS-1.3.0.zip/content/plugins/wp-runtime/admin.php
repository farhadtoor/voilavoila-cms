<?php
declare(strict_types=1);
namespace VV\WordPress;
use VV\{App,Security,Failure,Tools,Store};
defined('VV_ROOT') || exit;
final class RuntimeAdmin {
    public static function save(App $app,array $p): void {
        Security::requireOwner($app->store);Security::reauth($app->store,\val($p,'current_password'));$op=\val($p,'op');
        if($op==='open')Runtime::ticket($app,\val($p,'target','dashboard'));
        if($op==='prepare'){
            if(\val($p,'trust')!=='INSTALL')throw new Failure('Enter INSTALL to authorize trusted WordPress code.');
            $file=Tools::uploaded($_FILES['wordpress']??[],47185920);$db=[];foreach(['db_host','db_name','db_user','db_password'] as $key)$db[$key]=\val($p,$key);Runtime::prepare($app,$file,$db);return;
        }
        if($op==='wrap'){
            if(\val($p,'trust')!=='INSTALL')throw new Failure('Enter INSTALL to authorize trusted module code.');
            $file=Tools::uploaded($_FILES['module']??[],33554432);Runtime::wrap($app,$file,\val($p,'kind'));return;
        }
        if($op==='settings'){
            Runtime::config($app);$enabled=isset($p['enabled']);$home=isset($p['home']);
            $app->store->change(function(&$s)use($enabled,$home){$s['plugin_data']['wp-runtime']=array_merge($s['plugin_data']['wp-runtime']??[],['schema'=>1,'enabled'=>$enabled,'home'=>$enabled&&$home]);Store::log($s,'wp_runtime_settings');});return;
        }
        throw new Failure('Unknown runtime action.');
    }
    private static function start(string $op): string {return '<form method="post" enctype="multipart/form-data">'.\csrf_field().'<input type="hidden" name="action" value="plugin.save"><input type="hidden" name="op" value="'.\e($op).'">';}
    private static function password(): string {return '<label>'.\e(\t('Mot de passe actuel','Current password')).'<input type="password" name="current_password" required autocomplete="current-password"></label>';}
    public static function render(App $app): void {
        $error='';$cfg=null;try{$cfg=Runtime::config($app);}catch(\Throwable $e){$error=$e->getMessage();}$data=$app->state['plugin_data']['wp-runtime']??[];
        ?>
<section class="panel"><h2><?=\e(\t('WordPress facultatif · expérimental','Optional WordPress · experimental'))?></h2><p><?=\e(\t('Le CMS natif fonctionne sans WordPress. Ce module utilise un vrai moteur WordPress dans un pool PHP-FPM privé, avec une base MySQL/MariaDB distincte et une autre origine HTTPS. Il ne charge jamais wp-load.php dans le CMS.','The native CMS works without WordPress. This module uses genuine WordPress in a private PHP-FPM pool, a dedicated MySQL/MariaDB database and another HTTPS origin. It never loads wp-load.php in the CMS.'))?></p><p><?=\e(\t('Configuration serveur nécessaire : consultez docs/WP-RUNTIME.fr.md. Les thèmes, extensions et migrations métier demandent une qualification ; aucune compatibilité universelle ni accélération chiffrée n’est garantie.','Server configuration is required: see docs/WP-RUNTIME.md. Themes, plugins and business-data migrations need qualification; universal compatibility and specific speed gains are not guaranteed.'))?></p><?php if($error):?><p class="notice error"><?=\e($error)?></p><?php else:?><p><?=\e($cfg['public_url'])?> · <?=\e($data['version']??'—')?></p><?php endif;?></section>
<?php if(!$cfg)return;?>
<section class="panel"><h2><?=\e(\t('Exécution et accueil','Execution and home page'))?></h2><?=self::start('settings')?><label class="checkbox"><input type="checkbox" name="enabled" <?=!empty($data['enabled'])?'checked':''?>><?=\e(\t('Activer le moteur préparé','Enable the prepared engine'))?></label><label class="checkbox"><input type="checkbox" name="home" <?=!empty($data['home'])?'checked':''?>><?=\e(\t('Rediriger l’accueil natif vers WordPress','Redirect native home to WordPress'))?></label><?=self::password()?><button class="button primary"><?=\e(\t('Enregistrer','Save'))?></button></form></section>
<section class="panel"><h2><?=\e(\t('Accès propriétaire temporaire','Temporary owner access'))?></h2><p><?=\e(\t('Un ticket à usage unique initialise une base vide lors du premier accès. Les sessions du pont expirent après 30 minutes et sont révoquées à la modification du compte CMS.','A single-use ticket initializes an empty database on first access. Bridge sessions expire after 30 minutes and are revoked when the CMS account changes.'))?></p><?=self::start('open')?><select name="target"><?php foreach(['dashboard','themes','plugins','export','health'] as $target):?><option value="<?=$target?>"><?=$target?></option><?php endforeach;?></select><?=self::password()?><button class="button primary"><?=\e(\t('Ouvrir WordPress','Open WordPress'))?></button></form></section>
<details class="panel"><summary><?=\e(\t('Préparer une installation privée','Prepare a private installation'))?></summary><p><?=\e(\t('Utilisez le ZIP officiel vérifié et son bundle privé récent créé avec tools/fetch_wordpress_fixture.py. Aucune installation existante n’est écrasée.','Use the verified official ZIP and its recent private bundle produced with tools/fetch_wordpress_fixture.py. Existing installations are never overwritten.'))?></p><?=self::start('prepare')?><label>WordPress ZIP<input type="file" name="wordpress" accept=".zip" required></label><?php foreach(['db_host'=>'MySQL host','db_name'=>'Dedicated database','db_user'=>'Dedicated user','db_password'=>'Database password'] as $key=>$label):?><label><?=$label?><input name="<?=$key?>" type="<?=$key==='db_password'?'password':'text'?>" required autocomplete="off"></label><?php endforeach;?><label>INSTALL<input name="trust" pattern="INSTALL" required></label><?=self::password()?><button class="button primary"><?=\e(\t('Préparer','Prepare'))?></button></form></details>
<details class="panel"><summary><?=\e(\t('Installer un thème ou une extension WordPress de confiance','Install a trusted WordPress theme or plugin'))?></summary><p><?=\e(\t('Les modules PHP sont du code de confiance. Le manifeste SHA-256 est créé avec toutes les routes publiques fermées. Activez ensuite le module depuis WordPress.','PHP modules are trusted code. The SHA-256 manifest starts with all public routes closed. Activate the module from WordPress afterwards.'))?></p><?=self::start('wrap')?><select name="kind"><option value="theme">Theme</option><option value="plugin">Plugin</option></select><input type="file" name="module" accept=".zip" required><label>INSTALL<input name="trust" pattern="INSTALL" required></label><?=self::password()?><button class="button primary"><?=\e(\t('Installer dans le moteur','Install in engine'))?></button></form></details>
<?php }
}
