# Patch 1.1.0 → 1.2.0 / Update patch

FR : Sauvegardez le code et le stockage, activez la maintenance. Copiez le contenu de voila-cms dans votre installation 1.1.0, fichiers cachés compris. Aucun stockage d’exécution n’est fourni. Comparez les personnalisations des fichiers remplacés et les éventuels dossiers comments/wp-porter existants. Ne supprimez pas storage. Ne réinstallez pas le CMS. Après remplacement, ouvrez admin.php et lisez docs/fr/mise-a-jour-1.2.md. Les nouveaux plugins sont désactivés. Vérifiez le refus d’accès direct à la base et aux journaux avant de quitter la maintenance.

EN: Back up code and consistent storage, enable maintenance. Copy the contents of voila-cms over your 1.1.0 installation including dotfiles. No runtime storage is supplied. Compare customized files and any existing comments/wp-porter folders before replacement. Keep storage; do not reinstall. Open admin.php and read docs/en/upgrade-1.2.md. New plugins are inactive. Verify direct database/log denial before leaving maintenance.

Ce ZIP contient seulement les ajouts/modifications depuis l’archive 1.1.0 originale. Aucun fichier ancien n’est supprimé automatiquement. / This ZIP contains only additions/changes since original 1.1.0. It does not automatically remove old files.
